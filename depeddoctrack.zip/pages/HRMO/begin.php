<?php include('gate.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    
    <title><?php echo title; ?></title>
    <?php // echo css; ?>
    <!--<link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">-->
 
          
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/4.0.0/css/font-awesome.css" />
     <!-- Latest compiled and minified CSS -->
    <!--<link rel="stylesheet" href="../../libs/css/bootstrap.css">-->
    
    <link rel="stylesheet" href="../../libs/css/bootstrap-paper.css">
    
    <?php echo customcss; ?>
    <?php echo angular; ?>
    <script src="../../libs/js/dirPaginate.js"></script>
    <?php echo angularfilter; ?>    
    <?php echo angularroute; ?>
    <?php echo angularanimate; ?>
    <?php echo hrscript; ?>
    <script src="../../libs/js/ui-bootstrap.min.js"></script>
    
</head>
<body>