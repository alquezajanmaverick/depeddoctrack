<?php echo jquery; ?>
<?php echo js; ?>
<script src="../../libs/js/bootstrap-datepicker.js"></script>