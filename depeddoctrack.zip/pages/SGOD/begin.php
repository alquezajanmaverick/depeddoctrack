<?php include('gate.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    
    <title><?php echo title; ?></title>
    <?php echo css; ?>
    <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
     <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="../../libs/css/bootstrap.css">
    <?php echo angular; ?>
    <?php echo angularfilter; ?>
    <?php echo angularscript; ?>
    
</head>
<body>