<?php echo jquery; ?>
<?php echo js; ?>