<?php 
include("../../connection/PHPpdo.php");
$db = new DatabaseConnect();
$db->query("SELECT * from tblpositions");
$r = $db->resultset();
$row = $db->rowCount();

if($row >0)
{
    $js = json_encode($r);
}
echo $js;