
        
<nav class="navbar navbar-default navbar-fixed-top navbar-inverse" role="navigation">
        <div class="navbar-header">

            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                 <span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
            </button> <a class="navbar-brand" href="#">DepEd</a>
        </div>

        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li class="active">
                    <a href="#">Home</a>
                </li>
                <li class="dropdown">
                     <a href="#" class="dropdown-toggle" data-toggle="dropdown">Position<strong class="caret"></strong></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="add-position.php">Add New</a>
                        </li>
                        <li>
                            <a href="edit-position.php">Update Existing</a>
                        </li>
                        <li>
                            <a href="delete-position.php">Remove Exisiting</a>
                        </li>
                        <li class="divider">
                        </li>
                        <li>
                            <a href="search-position.php">Search</a>
                        </li>
                    </ul>
                </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <a href="../../log-out.php">Sign-Out</a>
                </li>
                
            </ul>
        </div>

    </nav>
    <br>
    <br>
    <br>
    <br>
    <br>